const { spawn } = require('child_process');
const http = require('http');

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

function startServer() {
    console.log("Starting Server...");
    const server = spawn('node', ['server.js'], { cwd: __dirname, shell: true });

    server.stdout.on('data', (data) => {
        // console.log(`[SERVER]: ${data}`);
    });

    server.stderr.on('data', (data) => {
        console.error(`[SERVER ERR]: ${data}`);
    });

    return server;
}

function doPost(path, data) {
    return new Promise((resolve, reject) => {
        const req = http.request({
            hostname: 'localhost',
            port: 5000,
            path: path,
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Content-Length': data.length
            }
        }, (res) => {
            let body = '';
            res.on('data', chunk => body += chunk);
            res.on('end', () => resolve({ status: res.statusCode, body }));
        });
        req.on('error', reject);
        req.write(data);
        req.end();
    });
}

async function runTest() {
    const username = `persist_user_${Date.now()}`;
    const userData = JSON.stringify({
        username: username,
        name: 'Test Persist',
        email: `${username}@test.com`,
        password: 'password123',
        gender: 'Male',
        background: 'Middle'
    });

    // 1. Start Server
    let server = startServer();
    await sleep(3000); // Wait for boot

    // 2. Register
    console.log(`Registering user: ${username}`);
    try {
        const res = await doPost('/api/register', userData);
        console.log("Register Response:", res.status, res.body);
        if (res.status !== 201) throw new Error("Registration Failed");
    } catch (e) {
        console.error("Setup failed:", e);
        server.kill();
        process.exit(1);
    }

    // 3. Kill Server
    console.log("Killing Server...");
    process.kill(server.pid);
    // On Windows spawning with shell: true might require tree kill, but let's try basic first
    // Actually, node spawn kill might not work well on Windows if not detached.
    // Let's rely on just spawning a NEW one, assuming the old one dies or we can use taskkill.
    require('child_process').execSync('taskkill /IM node.exe /F');
    await sleep(2000);

    // 4. Restart Server
    console.log("Restarting Server...");
    server = startServer();
    await sleep(3000);

    // 5. Login
    console.log("Attempting Login...");
    const loginData = JSON.stringify({ identifier: username, password: 'password123' });
    try {
        const res = await doPost('/api/login', loginData);
        console.log("Login Response:", res.status, res.body);

        if (res.status === 200) {
            console.log("SUCCESS: User persisted across restart.");
        } else {
            console.error("FAILURE: User lost.");
        }
    } catch (e) {
        console.error("Login test failed:", e);
    } finally {
        require('child_process').execSync('taskkill /IM node.exe /F');
    }
}

runTest();

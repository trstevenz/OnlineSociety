import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../services/api';
import Navbar from '../components/Navbar';
import StatCard from '../components/StatCard';
import ActionButtons from '../components/ActionButtons';

const Dashboard = () => {
    const [user, setUser] = useState(null);
    const [character, setCharacter] = useState(null);
    const [loading, setLoading] = useState(true);
    const [actionMessage, setActionMessage] = useState('');
    const navigate = useNavigate();

    const fetchProfile = async () => {
        try {
            const res = await api.get('/profile');
            setUser(res.data.user);
            setCharacter(res.data.character);
        } catch (err) {
            localStorage.removeItem('token');
            navigate('/login');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchProfile();
    }, []);

    const handleAction = async (actionType) => {
        try {
            const res = await api.post('/action', { actionType });
            setActionMessage(res.data.message);
            // Update stats locally or refetch
            setCharacter(prev => ({ ...prev, ...res.data.stats }));
            // Refetch to get updated age/days if server logic is complex
            // fetchProfile(); 
        } catch (err) {
            setActionMessage(err.response?.data?.error || 'Action failed');
        }
    };

    if (loading) return <div className="loading">Loading Life...</div>;

    return (
        <div className="dashboard">
            <Navbar />
            <div className="container dashboard-grid">

                {/* Top Section: Profile Info */}
                <div className="profile-header">
                    <h1>{character.name}</h1>
                    <div className="profile-meta">
                        <span>Age: {character.age}</span>
                        <span>Background: {character.background}</span>
                        <span>Job: {character.job}</span>
                    </div>
                </div>

                {/* Middle Section: Stats */}
                <div className="stats-grid">
                    <StatCard label="Health" value={character.health} color="red" />
                    <StatCard label="Money" value={`$${character.money}`} max={null} color="green" />
                    <StatCard label="Happiness" value={character.happiness} color="yellow" />
                    <StatCard label="Education" value={character.education} color="blue" />
                    <StatCard label="Hunger" value={character.hunger} color="orange" />
                    <StatCard label="Relations" value={character.relationship_score} color="purple" />
                </div>

                {/* Action Feedback */}
                {actionMessage && <div className="action-message">{actionMessage}</div>}

                {/* Bottom Section: Actions */}
                <ActionButtons onAction={handleAction} loading={loading} />

            </div>
        </div>
    );
};

export default Dashboard;

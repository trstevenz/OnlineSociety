import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../services/api';
import Navbar from '../components/Navbar';

const NewsPage = () => {
    const [announcements, setAnnouncements] = useState([]);
    const [selectedNews, setSelectedNews] = useState(null);
    const [loading, setLoading] = useState(true);
    const navigate = useNavigate();

    useEffect(() => {
        const fetchNews = async () => {
            try {
                const res = await api.get('/announcements');
                setAnnouncements(res.data);
            } catch (err) {
                console.error("Failed to load news", err);
            } finally {
                setLoading(false);
            }
        };
        fetchNews();
    }, []);

    const handleMarkRead = async (id, e) => {
        e.stopPropagation();
        try {
            await api.post(`/announcements/${id}/read`);
            setAnnouncements(prev => prev.map(a => a.id === id ? { ...a, is_read: 1 } : a));
        } catch (err) {
            console.error("Failed to mark read", err);
        }
    };

    if (loading) return <div className="loading">Loading News...</div>;

    return (
        <div className="dashboard">
            <Navbar />
            <div className="container" style={{ maxWidth: '800px', margin: '2rem auto' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem' }}>
                    <h1 style={{ color: '#f1c40f', margin: 0 }}>📰 Game News</h1>
                    <button onClick={() => navigate('/dashboard')} style={{ background: 'transparent', border: '1px solid #7f8c8d', color: '#bdc3c7', padding: '0.5rem 1rem', borderRadius: '4px', cursor: 'pointer' }}>
                        Back to Dashboard
                    </button>
                </div>

                {selectedNews ? (
                    <div className="news-detail" style={{ background: 'rgba(255,255,255,0.05)', padding: '2rem', borderRadius: '8px', borderLeft: '4px solid #f1c40f' }}>
                        <button onClick={() => setSelectedNews(null)} style={{ marginBottom: '1rem', background: 'none', border: 'none', color: '#3498db', cursor: 'pointer', fontSize: '0.9rem' }}>← Back to List</button>
                        <h2 style={{ color: '#f1c40f', marginTop: 0 }}>Announcement</h2>
                        <div style={{ fontSize: '1.1rem', lineHeight: '1.6', whiteSpace: 'pre-wrap' }}>{selectedNews.content}</div>
                        <div style={{ marginTop: '2rem', paddingTop: '1rem', borderTop: '1px solid rgba(255,255,255,0.1)', color: '#7f8c8d', fontSize: '0.9rem', display: 'flex', justifyContent: 'space-between' }}>
                            <span>Posted by {selectedNews.username}</span>
                            <span>{new Date(selectedNews.created_at).toLocaleString()}</span>
                        </div>
                    </div>
                ) : (
                    <div className="news-list" style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                        {announcements.map(ann => (
                            <div
                                key={ann.id}
                                onClick={() => setSelectedNews(ann)}
                                style={{
                                    background: ann.is_read ? 'rgba(255,255,255,0.02)' : 'rgba(241, 196, 15, 0.1)',
                                    padding: '1.5rem',
                                    borderRadius: '8px',
                                    cursor: 'pointer',
                                    borderLeft: ann.is_read ? '4px solid #7f8c8d' : '4px solid #f1c40f',
                                    transition: 'transform 0.2s'
                                }}
                                onMouseEnter={(e) => e.currentTarget.style.transform = 'translateX(5px)'}
                                onMouseLeave={(e) => e.currentTarget.style.transform = 'translateX(0)'}
                            >
                                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                                    <p style={{ margin: '0 0 0.5rem 0', fontSize: '1rem', fontWeight: ann.is_read ? 'normal' : 'bold', color: ann.is_read ? '#bdc3c7' : '#ecf0f1' }}>
                                        {ann.content.length > 100 ? ann.content.substring(0, 100) + '...' : ann.content}
                                    </p>
                                    {!ann.is_read && (
                                        <button
                                            onClick={(e) => handleMarkRead(ann.id, e)}
                                            style={{ background: '#f1c40f', color: '#2c3e50', border: 'none', padding: '0.3rem 0.8rem', borderRadius: '15px', fontSize: '0.75rem', fontWeight: 'bold', cursor: 'pointer' }}
                                        >
                                            Mark Read
                                        </button>
                                    )}
                                </div>
                                <div style={{ fontSize: '0.8rem', color: '#7f8c8d', marginTop: '0.5rem' }}>
                                    {new Date(ann.created_at).toLocaleDateString()}
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
};

export default NewsPage;

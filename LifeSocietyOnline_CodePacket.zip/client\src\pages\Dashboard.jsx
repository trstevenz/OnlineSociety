import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../services/api';
import GameHeader from '../components/GameHeader';
import ActionGrid from '../components/ActionGrid';
import StatCard from '../components/StatCard';
import ActionButtons from '../components/ActionButtons';

import ChatBox from '../components/ChatBox';
import MailSystem from '../components/MailSystem';
import Announcements from '../components/Announcements';
import UnreadAlerts from '../components/UnreadAlerts';
import GameNews from '../components/GameNews';

const Dashboard = () => {
    const [user, setUser] = useState(null);
    const [character, setCharacter] = useState(null);
    const [announcements, setAnnouncements] = useState([]); // New state
    const [loading, setLoading] = useState(true);
    const [actionMessage, setActionMessage] = useState('');
    const [tab, setTab] = useState('profile'); // 'profile', 'work', 'store', etc.
    const navigate = useNavigate();

    const fetchProfile = async () => {
        try {
            const res = await api.get('/profile');
            setUser(res.data.user);
            setCharacter(res.data.character);

            // Fetch Announcements
            const annRes = await api.get('/announcements');
            setAnnouncements(annRes.data);
        } catch (err) {
            // localStorage.removeItem('token');
            // navigate('/login');
            console.error("Profile fetch error:", err);
            setUser({ error: err.response?.data?.error || err.message });
        } finally {
            setLoading(false);
        }
    };

    const handleRead = (id) => {
        setAnnouncements(prev => prev.map(a => a.id === id ? { ...a, is_read: 1 } : a));
    };

    useEffect(() => {
        fetchProfile();
    }, []);

    const handleAction = async (actionType) => {
        try {
            const res = await api.post('/action', { actionType });
            setActionMessage(res.data.message);
            setCharacter(prev => ({ ...prev, ...res.data.stats }));
        } catch (err) {
            setActionMessage(err.response?.data?.error || 'Action failed');
        }
    };

    if (loading) return <div className="loading">Loading Life...</div>;
    if (user?.error) return <div style={{ color: 'red', padding: '2rem' }}>Error loading profile: {user.error} <br /> <button onClick={() => navigate('/login')}>Back to Login</button></div>;

    const renderContent = () => {
        switch (tab) {
            case 'profile':
                return (
                    <div className="animate-fade-in">
                        <div className="profile-header">
                            <h1>{character.name}</h1>
                            <div className="profile-meta">
                                <span>Background: {character.background}</span>
                                <span>Job: {character.job}</span>
                            </div>
                        </div>
                        <div className="stats-grid">
                            <StatCard label="Health" value={character.health} color="red" />
                            <StatCard label="Happiness" value={character.happiness} color="yellow" />
                            <StatCard label="Education" value={character.education} color="blue" />
                            <StatCard label="Hunger" value={character.hunger} color="orange" />
                            <StatCard label="Relations" value={character.relationship_score} color="purple" />
                        </div>
                        <ActionButtons onAction={handleAction} loading={loading} />
                        <div style={{ marginTop: '1rem', textAlign: 'center' }}>
                            <button onClick={() => { localStorage.removeItem('token'); navigate('/login'); }} style={{ background: '#c0392b', border: 'none', padding: '0.5rem 1rem', borderRadius: '4px', color: 'white', cursor: 'pointer' }}>Logout</button>
                        </div>
                    </div>
                );
            case 'community':
                return (
                    <div className="animate-fade-in" style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                        <Announcements />
                        <div style={{ textAlign: 'center', marginBottom: '0.5rem' }}>
                            <button
                                onClick={() => navigate('/news')}
                                style={{ background: 'rgba(241, 196, 15, 0.1)', border: '1px solid #f1c40f', color: '#f1c40f', padding: '0.5rem 1rem', borderRadius: '4px', cursor: 'pointer', fontSize: '0.9rem', width: '100%' }}
                            >
                                📰 View All Game News
                            </button>
                        </div>
                        <ChatBox userRole={user.role || 'user'} />
                        <MailSystem />
                    </div>
                );
            case 'work':
            case 'education':
            case 'store':
            case 'entertainment':
            case 'career':
                return (
                    <div style={{ padding: '2rem', textAlign: 'center', color: '#7f8c8d' }}>
                        <h2>{tab.charAt(0).toUpperCase() + tab.slice(1)}</h2>
                        <p>Coming soon...</p>
                        <button onClick={() => setTab('profile')} style={{ padding: '0.5rem', cursor: 'pointer' }}>Back to Profile</button>
                    </div>
                );
            default:
                return null;
        }
    };

    return (
        <div className="dashboard" style={{ padding: 0 }}>
            <GameHeader character={character} />

            <div className="container dashboard-grid" style={{ padding: '1rem', maxWidth: '600px', margin: '0 auto' }}>
                <UnreadAlerts announcements={announcements} onRead={handleRead} />

                {/* Cover Page */}
                <div style={{
                    height: '150px',
                    borderRadius: '12px',
                    background: 'linear-gradient(45deg, #2c3e50, #000)', // Placeholder until image loads
                    backgroundImage: 'url(/game_cover_cityscape.png), linear-gradient(45deg, #2c3e50, #000)',
                    backgroundSize: 'cover',
                    backgroundPosition: 'center',
                    marginBottom: '1rem',
                    position: 'relative',
                    overflow: 'hidden',
                    border: '1px solid rgba(255,255,255,0.1)'
                }}>
                    <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, padding: '0.5rem', background: 'linear-gradient(to top, rgba(0,0,0,0.8), transparent)' }}>
                        <h2 style={{ margin: 0, fontSize: '1rem', color: 'white' }}>Life Society Online</h2>
                    </div>
                </div>

                {/* Action Menu */}
                <ActionGrid onNavigate={setTab} activeTab={tab} />

                {/* Dynamic Content Area */}
                <div style={{ marginTop: '1rem', background: 'rgba(255,255,255,0.02)', padding: '1rem', borderRadius: '12px', border: '1px solid rgba(255,255,255,0.05)' }}>
                    {renderContent()}
                </div>
            </div>
        </div>
    );
};

export default Dashboard;

const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const dbPath = path.resolve(__dirname, 'lifesociety.db');
console.log("Reading DB from:", dbPath);

const db = new sqlite3.Database(dbPath, (err) => {
    if (err) { console.error(err); return; }
    db.all("SELECT id, username, email FROM users", (err, rows) => {
        if (err) console.error(err);
        else {
            console.log("--- USERS ---");
            console.table(rows);
            console.log("-------------");
        }
        db.close();
    });
});

import React from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../services/api';

const UnreadAlerts = ({ announcements, onRead }) => {
    const navigate = useNavigate();
    const unread = announcements.filter(a => !a.is_read);

    if (unread.length === 0) return null;

    const handleMarkRead = async (id) => {
        try {
            await api.post(`/announcements/${id}/read`);
            onRead(id);
        } catch (err) {
            console.error("Failed to mark read", err);
        }
    };

    return (
        <div style={{ marginBottom: '1rem', display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
            {unread.map(ann => (
                <div key={ann.id}
                    onClick={() => navigate('/news')}
                    style={{
                        background: 'linear-gradient(90deg, rgba(231, 76, 60, 0.2) 0%, rgba(231, 76, 60, 0.05) 100%)',
                        borderLeft: '4px solid #e74c3c',
                        padding: '1rem',
                        borderRadius: '8px',
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                        animation: 'slideIn 0.3s ease-out',
                        cursor: 'pointer'
                    }}>
                    <div>
                        <h4 style={{ margin: '0 0 0.3rem 0', color: '#e74c3c' }}>📢 New Announcement</h4>
                        <p style={{ margin: 0, fontSize: '0.95rem' }}>{ann.content}</p>
                        <span style={{ fontSize: '0.8rem', color: '#95a5a6' }}>{new Date(ann.created_at).toLocaleString()}</span>
                    </div>
                    <button
                        onClick={(e) => { e.stopPropagation(); handleMarkRead(ann.id); }}
                        style={{
                            background: '#e74c3c',
                            color: 'white',
                            border: 'none',
                            padding: '0.5rem 1rem',
                            borderRadius: '20px',
                            cursor: 'pointer',
                            fontWeight: 'bold',
                            whiteSpace: 'nowrap'
                        }}
                    >
                        Mark Read
                    </button>
                </div>
            ))}
        </div>
    );
};

export default UnreadAlerts;

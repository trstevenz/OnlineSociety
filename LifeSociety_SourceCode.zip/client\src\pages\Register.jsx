import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../services/api';

const Register = () => {
    const [formData, setFormData] = useState({
        username: '',
        name: '',
        email: '',
        password: '',
        gender: 'Male',
        background: 'Middle'
    });
    const [error, setError] = useState('');
    const navigate = useNavigate();

    const backgrounds = ['Rich', 'Middle', 'Lower Middle', 'Poor', 'Very Poor'];

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await api.post('/register', formData);
            navigate('/login');
        } catch (err) {
            setError(err.response?.data?.error || 'Registration failed');
        }
    };

    return (
        <div className="auth-container">
            <h2>Start Your Life</h2>
            {error && <p className="error">{error}</p>}
            <form onSubmit={handleSubmit}>
                <input name="name" placeholder="Full Name" onChange={handleChange} required />
                <input name="username" placeholder="Username" onChange={handleChange} required />
                <input name="email" type="email" placeholder="Email" onChange={handleChange} required />
                <input name="password" type="password" placeholder="Password" onChange={handleChange} required />

                <select name="gender" onChange={handleChange}>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                </select>

                <select name="background" onChange={handleChange}>
                    {backgrounds.map(bg => <option key={bg} value={bg}>{bg}</option>)}
                </select>

                <button type="submit">Born Into World</button>
            </form>
            <p style={{ marginTop: '1rem', textAlign: 'center' }}>
                Already alive? <span style={{ color: '#3b82f6', cursor: 'pointer' }} onClick={() => navigate('/login')}>Wake Up</span>
            </p>
        </div>
    );
};

export default Register;

const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const bcrypt = require('bcrypt');

const dbPath = path.resolve(__dirname, 'lifesociety.db');
const db = new sqlite3.Database(dbPath);

const identifier = 'admin';
const password = 'admin@123';

console.log(`Checking login for: ${identifier} with password: ${password}`);

db.get(`SELECT * FROM users WHERE email = ? OR username = ?`, [identifier, identifier], async (err, user) => {
    if (err) {
        console.error("DB Error:", err);
        return;
    }
    if (!user) {
        console.error("User not found!");
        return;
    }

    console.log("User found:", user.username, "| Role:", user.role, "| Banned:", user.is_banned);
    console.log("Stored Hash:", user.password);

    try {
        const match = await bcrypt.compare(password, user.password);
        console.log("Password Match:", match);
    } catch (e) {
        console.error("Bcrypt Error:", e);
    }
});

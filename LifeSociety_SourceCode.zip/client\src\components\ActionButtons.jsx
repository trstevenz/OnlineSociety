import React from 'react';

const ActionButtons = ({ onAction, loading }) => {
    const actions = [
        { type: 'WORK', label: 'Work', icon: '💼', cost: '-Health', gain: '+Money' },
        { type: 'STUDY', label: 'Study', icon: '📚', cost: '-Happy', gain: '+Edu' },
        { type: 'EAT', label: 'Eat', icon: '🍔', cost: '-Money', gain: '+Health' },
        { type: 'SOCIALIZE', label: 'Socialize', icon: '🎉', cost: '-Money', gain: '+Happy' },
        { type: 'REST', label: 'Rest', icon: '🛌', cost: 'Time', gain: '+Health' },
    ];

    return (
        <div className="action-buttons-grid">
            {actions.map((action) => (
                <button
                    key={action.type}
                    onClick={() => onAction(action.type)}
                    disabled={loading}
                    className="action-btn"
                >
                    <span className="icon">{action.icon}</span>
                    <span className="label">{action.label}</span>
                    <div className="tooltip">
                        <small>{action.cost} / {action.gain}</small>
                    </div>
                </button>
            ))}
        </div>
    );
};

export default ActionButtons;

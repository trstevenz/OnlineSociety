import React from 'react';

const StatCard = ({ label, value, max = 100, color = 'blue' }) => {
    // Basic progress bar calculation if max is provided
    const percentage = Math.min(100, Math.max(0, (value / max) * 100));

    return (
        <div className={`stat-card stat-${color}`}>
            <h3>{label}</h3>
            <div className="value">{value}</div>
            {max && (
                <div className="progress-bar">
                    <div
                        className="progress-fill"
                        style={{ width: `${percentage}%` }}
                    ></div>
                </div>
            )}
        </div>
    );
};

export default StatCard;

import React, { useState, useEffect } from 'react';
import api from '../services/api';

const MailSystem = () => {
    const [mail, setMail] = useState([]);
    const [tab, setTab] = useState('inbox'); // inbox, compose
    const [receiver, setReceiver] = useState('');
    const [subject, setSubject] = useState('');
    const [content, setContent] = useState('');

    const fetchMail = async () => {
        try {
            const res = await api.get('/mail');
            setMail(res.data);
        } catch (err) {
            console.error("Mail error");
        }
    };

    useEffect(() => {
        if (tab === 'inbox') fetchMail();
    }, [tab]);

    const handleSend = async (e) => {
        e.preventDefault();
        try {
            await api.post('/mail', { receiverUsername: receiver, subject, content });
            alert("Mail Sent!");
            setReceiver('');
            setSubject('');
            setContent('');
            setTab('inbox');
        } catch (err) {
            alert(err.response?.data?.error || "Failed to send");
        }
    };

    return (
        <div className="glass-panel">
            <div style={{ display: 'flex', gap: '1rem', marginBottom: '1rem', borderBottom: '1px solid rgba(255,255,255,0.1)' }}>
                <button onClick={() => setTab('inbox')} style={{ background: 'transparent', borderBottom: tab === 'inbox' ? '2px solid white' : 'none' }}>Inbox</button>
                <button onClick={() => setTab('compose')} style={{ background: 'transparent', borderBottom: tab === 'compose' ? '2px solid white' : 'none' }}>Compose</button>
            </div>

            {tab === 'inbox' ? (
                <div style={{ maxHeight: '300px', overflowY: 'auto' }}>
                    {mail.length === 0 ? <p>No mail.</p> : mail.map(m => (
                        <div key={m.id} style={{ background: 'rgba(255,255,255,0.05)', padding: '0.5rem', marginBottom: '0.5rem', borderRadius: '0.5rem' }}>
                            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                                <strong>From: {m.sender_name}</strong>
                                <small>{new Date(m.created_at).toLocaleDateString()}</small>
                            </div>
                            <div style={{ fontWeight: 'bold' }}>{m.subject}</div>
                            <p style={{ margin: '0.5rem 0' }}>{m.content}</p>
                        </div>
                    ))}
                </div>
            ) : (
                <form onSubmit={handleSend} style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                    <input placeholder="To (Username)" value={receiver} onChange={e => setReceiver(e.target.value)} required />
                    <input placeholder="Subject" value={subject} onChange={e => setSubject(e.target.value)} required />
                    <textarea placeholder="Message" value={content} onChange={e => setContent(e.target.value)} required style={{ minHeight: '100px' }}></textarea>
                    <button type="submit">Send Mail</button>
                </form>
            )}
        </div>
    );
};

export default MailSystem;

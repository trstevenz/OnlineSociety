const axios = require('axios');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const dbPath = path.resolve(__dirname, 'lifesociety.db');
const db = new sqlite3.Database(dbPath);

const testUser = {
    username: 'testuser_' + Date.now(),
    email: 'test_' + Date.now() + '@example.com',
    password: 'password123',
    name: 'Test User',
    background: 'Rich'
};

async function testRegistration() {
    console.log("Attempting to register:", testUser.username);
    try {
        const res = await axios.post('http://localhost:5000/api/register', testUser);
        console.log("Registration Response:", res.status, res.data);
    } catch (e) {
        console.error("Registration Failed:", e.response ? e.response.data : e.message);
        return;
    }

    // Verify DB
    db.get("SELECT * FROM users WHERE username = ?", [testUser.username], (err, user) => {
        if (err) console.error(err);
        if (!user) {
            console.error("USER NOT FOUND IN DB!");
        } else {
            console.log("User found in DB:", user);
            console.log("Is Banned:", user.is_banned);

            db.get("SELECT * FROM characters WHERE user_id = ?", [user.id], (err, char) => {
                if (err) console.error(err);
                if (!char) {
                    console.error("CHARACTER NOT FOUND FOR USER!");
                } else {
                    console.log("Character found:", char.name);
                }
            });
        }
    });
}

testRegistration();

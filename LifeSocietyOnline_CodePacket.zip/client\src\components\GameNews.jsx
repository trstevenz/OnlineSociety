import React from 'react';

const GameNews = ({ announcements }) => {
    return (
        <div className="game-news-section" style={{ marginTop: '2rem', borderTop: '1px solid rgba(255,255,255,0.1)', paddingTop: '1rem' }}>
            <h3 style={{ color: '#f1c40f', marginBottom: '1rem' }}>📰 Game News Archive</h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                {announcements.length === 0 ? (
                    <p style={{ color: '#7f8c8d', fontStyle: 'italic' }}>No news yet.</p>
                ) : (
                    announcements.map(ann => (
                        <div key={ann.id} style={{
                            background: 'rgba(255,255,255,0.03)',
                            padding: '1rem',
                            borderRadius: '8px',
                            opacity: ann.is_read ? 0.7 : 1
                        }}>
                            <p style={{ margin: '0 0 0.5rem 0', fontSize: '0.95rem' }}>{ann.content}</p>
                            <div style={{ fontSize: '0.75rem', color: '#7f8c8d', display: 'flex', justifyContent: 'space-between' }}>
                                <span>Posted by {ann.username}</span>
                                <span>{new Date(ann.created_at).toLocaleDateString()}</span>
                            </div>
                        </div>
                    ))
                )}
            </div>
        </div>
    );
};

export default GameNews;

import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../services/api';
import Navbar from '../components/Navbar';
import ChatBox from '../components/ChatBox';
import MailSystem from '../components/MailSystem';

const AdminDashboard = () => {
    const navigate = useNavigate();
    const [activeTab, setActiveTab] = useState('users');
    const [stats, setStats] = useState(null);
    const [users, setUsers] = useState([]);
    const [logs, setLogs] = useState([]);
    const [isMenuOpen, setIsMenuOpen] = useState(false); // Mobile Menu State

    // Ban Modal State
    const [showBanModal, setShowBanModal] = useState(false);
    const [selectedUser, setSelectedUser] = useState(null);
    const [banReason, setBanReason] = useState('');
    const [banDuration, setBanDuration] = useState('24'); // Default 24 hours

    // Fetch data based on tab
    useEffect(() => {
        if (activeTab === 'users') fetchUsers();
        if (activeTab === 'stats') fetchStats();
        if (activeTab === 'logs') fetchLogs();
    }, [activeTab]);

    const fetchUsers = async () => {
        try {
            const res = await api.get('/admin/users');
            setUsers(res.data);
        } catch (error) {
            console.error("Failed to fetch users", error);
        }
    };

    const fetchStats = async () => {
        const res = await api.get('/admin/stats');
        setStats(res.data);
    };

    const fetchLogs = async () => {
        const res = await api.get('/admin/logs');
        setLogs(res.data);
    };

    const handlePromote = async (userId) => {
        if (window.confirm("Promote user to Moderator?")) {
            await api.post('/admin/promote', { userId, role: 'moderator' });
            fetchUsers();
        }
    };

    const openBanModal = (user) => {
        setSelectedUser(user);
        setBanReason('');
        setBanDuration('24');
        setShowBanModal(true);
    };

    const confirmBan = async () => {
        if (!banReason) return alert("Please provide a reason.");

        await api.post('/admin/ban', {
            userId: selectedUser.id,
            reason: banReason,
            duration: banDuration
        });
        setShowBanModal(false);
        fetchUsers();
    };

    const handleUnban = async (userId) => {
        if (window.confirm("Unban this user?")) {
            await api.post('/admin/unban', { userId });
            fetchUsers();
        }
    };

    const handleDelete = async (userId) => {
        if (window.confirm("Permanently delete this user? This cannot be undone.")) {
            await api.delete(`/admin/users/${userId}`);
            fetchUsers();
        }
    };

    const handleAnnounce = async () => {
        const content = prompt("Announcement Content:");
        if (content) {
            await api.post('/admin/announcements', { content });
            alert("Announcement Posted!");
        }
    };

    return (
        <div className="dashboard-layout" style={{
            position: 'relative', // Restored to relative for mobile simulation
            height: '100%',
            background: '#1a1a1a',
            color: 'white',
            display: 'flex',
            flexDirection: 'column',
            overflow: 'hidden'
        }}>
            {/* Header / Navbar Replacement */}
            <div style={{ padding: '1rem', background: '#2c3e50', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <button onClick={() => setIsMenuOpen(!isMenuOpen)} style={{ background: 'transparent', border: 'none', color: 'white', fontSize: '1.5rem', cursor: 'pointer' }}>
                    ☰
                </button>
                <h2 style={{ margin: 0, fontSize: '1.2rem' }}>Admin Panel</h2>
                {/* Changed to use React Router navigate if available, otherwise window.location is fallback but href causes reload */}
                <button onClick={() => { localStorage.removeItem('token'); navigate('/login'); }} style={{ background: '#e74c3c', border: 'none', padding: '0.4rem 0.8rem', borderRadius: '4px', color: 'white', cursor: 'pointer', fontSize: '0.8rem' }}>
                    Logout
                </button>
            </div>

            {/* Mobile Sidebar (Drawer) */}
            <div className={`sidebar-drawer ${isMenuOpen ? 'open' : ''}`} style={{
                position: 'absolute',
                top: 0,
                left: isMenuOpen ? 0 : '-100%',
                width: '70%',
                height: '100%',
                background: '#2c3e50',
                zIndex: 100,
                transition: 'left 0.3s ease',
                padding: '1rem',
                display: 'flex',
                flexDirection: 'column',
                gap: '1rem',
                boxShadow: '2px 0 10px rgba(0,0,0,0.5)'
            }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid #7f8c8d', paddingBottom: '0.5rem' }}>
                    <h2 style={{ margin: 0 }}>Menu</h2>
                    <button onClick={() => setIsMenuOpen(false)} style={{ background: 'transparent', border: 'none', color: 'white', fontSize: '1.5rem', cursor: 'pointer' }}>×</button>
                </div>

                <nav style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                    {['users', 'stats', 'logs', 'chat', 'mail'].map(tab => (
                        <button
                            key={tab}
                            onClick={() => { setActiveTab(tab); setIsMenuOpen(false); }}
                            style={{
                                background: activeTab === tab ? '#3498db' : 'transparent',
                                color: 'white',
                                border: 'none',
                                padding: '0.75rem',
                                borderRadius: '4px',
                                textAlign: 'left',
                                cursor: 'pointer',
                                transition: 'background 0.2s'
                            }}
                        >
                            {tab.charAt(0).toUpperCase() + tab.slice(1)}
                        </button>
                    ))}
                </nav>

                <div style={{ marginTop: 'auto' }}>
                    <button onClick={handleAnnounce} style={{ width: '100%', padding: '0.75rem', background: '#e67e22', border: 'none', borderRadius: '4px', color: 'white', cursor: 'pointer' }}>
                        📢 Post Announcement
                    </button>
                    <button onClick={() => { localStorage.removeItem('token'); navigate('/login'); }} style={{ width: '100%', marginTop: '0.5rem', padding: '0.75rem', background: '#e74c3c', border: 'none', borderRadius: '4px', color: 'white', cursor: 'pointer' }}>
                        🚪 Logout
                    </button>
                </div>
            </div>

            {/* Overlay for Drawer */}
            {isMenuOpen && (
                <div onClick={() => setIsMenuOpen(false)} style={{
                    position: 'absolute', top: 0, left: 0, width: '100%', height: '100%',
                    background: 'rgba(0,0,0,0.5)', zIndex: 90
                }} />
            )}

            {/* Main Content */}
            <div className="main-content" style={{ flex: 1, padding: '1rem', overflowY: 'auto' }}>
                {activeTab === 'users' && (
                    <div>
                        <h2 style={{ marginBottom: '1rem', fontSize: '1.2rem' }}>User Management</h2>
                        <div className="glass-panel" style={{ background: '#34495e', padding: '0.5rem', borderRadius: '8px', overflowX: 'auto' }}>
                            <table style={{ width: '100%', borderCollapse: 'collapse', minWidth: '400px' }}>
                                <thead>
                                    <tr style={{ textAlign: 'left', borderBottom: '2px solid #7f8c8d', color: '#ecf0f1' }}>
                                        <th style={{ padding: '0.5rem' }}>User</th>
                                        <th style={{ padding: '0.5rem' }}>Status</th>
                                        <th style={{ padding: '0.5rem' }}>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {users.map(u => (
                                        <tr key={u.id} style={{ borderBottom: '1px solid #7f8c8d' }}>
                                            <td style={{ padding: '0.75rem' }}>
                                                <strong>{u.username}</strong> <br />
                                                <span style={{ fontSize: '0.7rem', opacity: 0.7 }}>{u.role}</span>
                                            </td>
                                            <td style={{ padding: '0.75rem' }}>
                                                {u.is_banned ?
                                                    <span style={{ color: '#e74c3c', fontSize: '0.8rem' }}>
                                                        ⛔ BANNED
                                                    </span> :
                                                    <span style={{ color: '#2ecc71', fontSize: '0.8rem' }}>Active</span>
                                                }
                                                {u.is_online && <span style={{ color: '#2ecc71', marginLeft: '0.2rem' }}>•</span>}
                                            </td>
                                            <td style={{ padding: '0.75rem', display: 'flex', flexDirection: 'column', gap: '0.3rem' }}>
                                                {u.role === 'user' && !u.is_banned && (
                                                    <button onClick={() => handlePromote(u.id)} style={{ padding: '0.3rem 0.6rem', background: '#3498db', border: 'none', borderRadius: '4px', color: 'white', cursor: 'pointer', fontSize: '0.7rem' }}>Promote</button>
                                                )}
                                                {u.is_banned ?
                                                    <button onClick={() => handleUnban(u.id)} style={{ padding: '0.3rem 0.6rem', background: '#2ecc71', border: 'none', borderRadius: '4px', color: 'white', cursor: 'pointer', fontSize: '0.7rem' }}>Unban</button> :
                                                    <button onClick={() => openBanModal(u)} style={{ padding: '0.3rem 0.6rem', background: '#e74c3c', border: 'none', borderRadius: '4px', color: 'white', cursor: 'pointer', fontSize: '0.7rem' }}>Ban</button>
                                                }
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                )}

                {activeTab === 'stats' && stats && (
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.5rem' }}>
                        <div className="stat-card" style={{ background: '#34495e', padding: '1rem', borderRadius: '8px', textAlign: 'center' }}>
                            <h1 style={{ fontSize: '2rem', margin: 0 }}>{stats.totalUsers}</h1>
                            <p style={{ opacity: 0.8, fontSize: '0.8rem' }}>Total Users</p>
                        </div>
                        <div className="stat-card" style={{ background: '#27ae60', padding: '1rem', borderRadius: '8px', textAlign: 'center' }}>
                            <h1 style={{ fontSize: '2rem', margin: 0 }}>{stats.activeUsers}</h1>
                            <p style={{ opacity: 0.8, fontSize: '0.8rem' }}>Active (1h)</p>
                        </div>
                    </div>
                )}

                {activeTab === 'logs' && (
                    <div className="glass-panel" style={{ background: '#34495e', padding: '0.5rem', borderRadius: '8px', maxHeight: '500px', overflowY: 'auto' }}>
                        <h2 style={{ marginBottom: '0.5rem', fontSize: '1.2rem' }}>Activity Logs</h2>
                        {logs.map(l => (
                            <div key={l.id} style={{ borderBottom: '1px solid rgba(255,255,255,0.1)', padding: '0.5rem', fontSize: '0.8rem' }}>
                                <div>
                                    <strong>{l.username || 'System'}</strong> <span style={{ opacity: 0.7 }}>{l.action_type}</span>
                                </div>
                                <div style={{ marginTop: '0.2rem', opacity: 0.9 }}>{l.description}</div>
                                <small style={{ opacity: 0.5 }}>{new Date(l.created_at).toLocaleString()}</small>
                            </div>
                        ))}
                    </div>
                )}

                {activeTab === 'chat' && <ChatBox userRole="admin" />}
                {activeTab === 'mail' && <MailSystem />}
            </div>

            {/* Ban Modal */}
            {showBanModal && (
                <div style={{
                    position: 'absolute', top: 0, left: 0, width: '100%', height: '100%',
                    background: 'rgba(0,0,0,0.8)', display: 'flex', justifyContent: 'center', alignItems: 'center',
                    zIndex: 1000
                }}>
                    <div style={{ background: '#2c3e50', padding: '1.5rem', borderRadius: '8px', width: '90%', maxWidth: '350px', color: 'white' }}>
                        <h3>Ban: {selectedUser?.username}</h3>

                        <div style={{ marginBottom: '1rem' }}>
                            <label style={{ display: 'block', marginBottom: '0.5rem', fontSize: '0.9rem' }}>Reason</label>
                            <input
                                type="text"
                                value={banReason}
                                onChange={(e) => setBanReason(e.target.value)}
                                style={{ width: '100%', padding: '0.5rem', borderRadius: '4px', border: 'none' }}
                                placeholder="Reason..."
                            />
                        </div>

                        <div style={{ marginBottom: '1.5rem' }}>
                            <label style={{ display: 'block', marginBottom: '0.5rem', fontSize: '0.9rem' }}>Duration</label>
                            <select
                                value={banDuration}
                                onChange={(e) => setBanDuration(e.target.value)}
                                style={{ width: '100%', padding: '0.5rem', borderRadius: '4px', border: 'none' }}
                            >
                                <option value="1">1 Hour</option>
                                <option value="6">6 Hours</option>
                                <option value="24">24 Hours</option>
                                <option value="72">3 Days</option>
                                <option value="168">1 Week</option>
                                <option value="permanent">Permanent</option>
                            </select>
                        </div>

                        <div style={{ display: 'flex', gap: '0.5rem', justifyContent: 'flex-end' }}>
                            <button onClick={() => setShowBanModal(false)} style={{ padding: '0.5rem', background: 'transparent', color: 'white', border: '1px solid #7f8c8d', borderRadius: '4px', cursor: 'pointer' }}>Cancel</button>
                            <button onClick={confirmBan} style={{ padding: '0.5rem', background: '#e74c3c', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>Ban</button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default AdminDashboard;

const http = require('http');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const dbPath = path.resolve(__dirname, 'lifesociety.db');
const db = new sqlite3.Database(dbPath);

const testUser = {
    username: 'testuser_' + Date.now(),
    email: 'test_' + Date.now() + '@example.com',
    password: 'password123',
    name: 'Test User',
    background: 'Rich'
};

const data = JSON.stringify(testUser);

const options = {
    hostname: 'localhost',

    port: 5000,
    path: '/api/register',
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
        'Content-Length': data.length
    }
};

console.log("Attempting to register:", testUser.username);

const req = http.request(options, (res) => {
    console.log(`STATUS: ${res.statusCode}`);

    let body = '';
    res.setEncoding('utf8');
    res.on('data', (chunk) => body += chunk);
    res.on('end', () => {
        console.log(`BODY: ${body}`);

        // Check DB immediately after
        setTimeout(checkDB, 1000);
    });
});

req.on('error', (e) => {
    console.error(`problem with request: ${e.message}`);
});

req.write(data);
req.end();

function checkDB() {
    console.log("--- Verifying in DB ---");
    db.get("SELECT * FROM users WHERE username = ?", [testUser.username], (err, user) => {
        if (err) console.error(err);
        if (!user) {
            console.error("USER NOT FOUND IN DB!");
        } else {
            console.log("User found in DB:", user.username, "| ID:", user.id);
            console.log("Is Banned:", user.is_banned);

            db.get("SELECT * FROM characters WHERE user_id = ?", [user.id], (err, char) => {
                if (err) console.error(err);
                if (!char) {
                    console.error("CHARACTER NOT FOUND FOR USER!");
                } else {
                    console.log("Character found:", char.name);
                }
            });
        }
    });
}

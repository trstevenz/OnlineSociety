import React, { useEffect, useState } from 'react';
import api from '../services/api';

const Announcements = () => {
    const [announcements, setAnnouncements] = useState([]);

    useEffect(() => {
        const fetchAnnouncements = async () => {
            try {
                const res = await api.get('/announcements');
                setAnnouncements(res.data);
            } catch (err) {
                console.error("Failed to load announcements", err);
            }
        };
        fetchAnnouncements();
    }, []);

    const unreadAnnouncements = announcements.filter(a => !a.is_read);

    if (unreadAnnouncements.length === 0) return null;

    return (
        <div className="announcements-list" style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            <h3 style={{ margin: '0 0 1rem 0', color: '#e67e22' }}>📢 Official Announcements</h3>
            {unreadAnnouncements.map((ann, index) => (
                <div key={index} style={{ background: 'rgba(255,255,255,0.05)', padding: '1rem', borderRadius: '8px', borderLeft: '3px solid #e67e22' }}>
                    <p style={{ margin: '0 0 0.5rem 0', fontSize: '1rem' }}>{ann.content}</p>
                    <div style={{ fontSize: '0.8rem', color: '#bdc3c7', display: 'flex', justifyContent: 'space-between' }}>
                        <span>By {ann.username || 'Admin'}</span>
                        <span>{new Date(ann.created_at).toLocaleString()}</span>
                    </div>
                </div>
            ))}
        </div>
    );
};

export default Announcements;

const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const fs = require('fs');

const dbPath = path.resolve(__dirname, 'lifesociety.db');

const db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
        console.error('Error opening database:', err.message);
    } else {
        console.log('------------------------------------------------');
        console.log('DATABASE CONNECTION SUCCESS');
        console.log('Path:', dbPath);
        try {
            const stats = fs.statSync(dbPath);
            console.log('Size:', stats.size, 'bytes');
        } catch (e) {
            console.log('Size: New File (0 bytes)');
        }
        console.log('------------------------------------------------');

        db.serialize(() => {
            // Users Table
            db.run(`CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE,
                email TEXT UNIQUE,
                password TEXT,
                created_at TEXT
            )`);

            // Add new columns to users table safely
            const columnsToAdd = [
                "ALTER TABLE users ADD COLUMN role TEXT DEFAULT 'user'",
                "ALTER TABLE users ADD COLUMN is_banned BOOLEAN DEFAULT 0",
                "ALTER TABLE users ADD COLUMN ban_expires_at TEXT",
                "ALTER TABLE users ADD COLUMN is_online BOOLEAN DEFAULT 0",
                "ALTER TABLE users ADD COLUMN last_active_at TEXT"
            ];

            columnsToAdd.forEach(query => {
                db.run(query, (err) => {
                    // Ignore duplicate column errors
                    if (err && !err.message.includes('duplicate column name')) {
                        console.error("Schema update error:", err.message);
                    }
                });
            });

            // Characters Table
            db.run(`CREATE TABLE IF NOT EXISTS characters (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                name TEXT,
                background TEXT,
                age INTEGER,
                money INTEGER,
                health INTEGER,
                education INTEGER,
                happiness INTEGER,
                hunger INTEGER,
                relationship_score INTEGER,
                job TEXT,
                profession_level INTEGER,
                FOREIGN KEY(user_id) REFERENCES users(id)
            )`);

            // Chat Messages Table
            db.run(`CREATE TABLE IF NOT EXISTS chat_messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                message TEXT,
                created_at TEXT,
                FOREIGN KEY(user_id) REFERENCES users(id)
            )`);

            // Announcements Table
            db.run(`CREATE TABLE IF NOT EXISTS announcements (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                admin_id INTEGER,
                content TEXT,
                created_at TEXT,
                FOREIGN KEY(admin_id) REFERENCES users(id)
            )`);

            // Mail Table
            db.run(`CREATE TABLE IF NOT EXISTS mail (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                sender_id INTEGER,
                receiver_id INTEGER,
                subject TEXT,
                content TEXT,
                is_read BOOLEAN DEFAULT 0,
                created_at TEXT,
                FOREIGN KEY(sender_id) REFERENCES users(id),
                FOREIGN KEY(receiver_id) REFERENCES users(id)
            )`);

            // Activity Logs Table
            db.run(`CREATE TABLE IF NOT EXISTS activity_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                action_type TEXT,
                description TEXT,
                created_at TEXT,
                FOREIGN KEY(user_id) REFERENCES users(id)
            )`);

            // Announcement Reads Table (Track which user read which announcement)
            db.run(`CREATE TABLE IF NOT EXISTS announcement_reads (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                announcement_id INTEGER,
                read_at TEXT,
                FOREIGN KEY(user_id) REFERENCES users(id),
                FOREIGN KEY(announcement_id) REFERENCES announcements(id)
            )`);

            // DEBUG: List all users on startup
            db.all("SELECT id, username, role FROM users", (err, rows) => {
                if (err) console.error("Failed to list users:", err);
                else {
                    console.log("\n--- EXISTING USERS ---");
                    if (rows.length === 0) console.log("No users found.");
                    else rows.forEach(r => console.log(`[${r.id}] ${r.username} (${r.role})`));
                    console.log("----------------------\n");
                }
            });
        });
    }
});

module.exports = db;

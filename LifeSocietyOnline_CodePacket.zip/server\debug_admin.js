const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const dbPath = path.resolve(__dirname, 'lifesociety.db');
const db = new sqlite3.Database(dbPath);

db.serialize(() => {
    console.log("--- Users Table Dump ---");
    db.all("SELECT id, username, email, role, is_banned FROM users", (err, rows) => {
        if (err) {
            console.error(err);
        } else {
            console.table(rows);
        }
    });
});

db.close();

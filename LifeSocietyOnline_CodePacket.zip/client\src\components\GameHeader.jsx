import React from 'react';

const GameHeader = ({ character }) => {
    if (!character) return null;

    return (
        <div style={{
            position: 'sticky',
            top: 0,
            zIndex: 1000,
            background: 'rgba(15, 15, 20, 0.95)',
            backdropFilter: 'blur(10px)',
            borderBottom: '1px solid rgba(255, 255, 255, 0.1)',
            padding: '0.5rem 1rem',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            boxShadow: '0 4px 15px rgba(0,0,0,0.3)'
        }}>
            {/* Left: Age / XP Progress */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '2px', width: '40%' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.75rem', color: '#bdc3c7' }}>
                    <span>Age {character.age}</span>
                    <span>Next: {character.age + 1}</span>
                </div>
                <div style={{ width: '100%', height: '6px', background: 'rgba(255,255,255,0.1)', borderRadius: '3px', overflow: 'hidden' }}>
                    <div style={{
                        width: `${character.age_progress || 0}%`,
                        height: '100%',
                        background: 'linear-gradient(90deg, #3498db, #2ecc71)',
                        transition: 'width 0.5s ease'
                    }} />
                </div>
                <div style={{ fontSize: '0.65rem', color: '#7f8c8d', textAlign: 'right' }}>
                    {character.age_progress || 0}% to next age
                </div>
            </div>

            {/* Right: Money */}
            <div style={{
                display: 'flex',
                alignItems: 'center',
                gap: '0.5rem',
                background: 'rgba(46, 204, 113, 0.1)',
                padding: '0.3rem 0.8rem',
                borderRadius: '20px',
                border: '1px solid rgba(46, 204, 113, 0.3)'
            }}>
                <span style={{ fontSize: '1.2rem' }}>💵</span>
                <span style={{ fontSize: '1rem', fontWeight: 'bold', color: '#2ecc71', fontFamily: 'monospace' }}>
                    ${character.money?.toLocaleString()}
                </span>
            </div>
        </div>
    );
};

export default GameHeader;

const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const dbPath = path.resolve(__dirname, 'lifesociety.db');

const db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
        console.error('Error opening database:', err.message);
    } else {
        console.log('Connected to the SQLite database.');
        
        db.serialize(() => {
            // Users Table
            db.run(`CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE,
                email TEXT UNIQUE,
                password TEXT,
                created_at TEXT
            )`);

            // Characters Table
            db.run(`CREATE TABLE IF NOT EXISTS characters (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                name TEXT,
                background TEXT,
                age INTEGER,
                money INTEGER,
                health INTEGER,
                education INTEGER,
                happiness INTEGER,
                hunger INTEGER,
                relationship_score INTEGER,
                job TEXT,
                profession_level INTEGER,
                FOREIGN KEY(user_id) REFERENCES users(id)
            )`);
        });
    }
});

module.exports = db;

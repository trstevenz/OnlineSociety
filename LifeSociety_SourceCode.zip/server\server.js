const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const db = require('./database');

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;
const JWT_SECRET = process.env.JWT_SECRET || 'supersecretkey'; // In prod, use .env

app.use(cors());
app.use(express.json());

// Middleware to authenticate token
const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) return res.sendStatus(401);

    jwt.verify(token, JWT_SECRET, (err, user) => {
        if (err) return res.sendStatus(403);
        req.user = user;
        next();
    });
};

// --- ADMIN MIDDLEWARE ---
const authenticateAdmin = (req, res, next) => {
    authenticateToken(req, res, () => {
        if (req.user.username === 'admin') {
            next();
        } else {
            res.sendStatus(403);
        }
    });
};

// --- AUTH ENDPOINTS ---

// Register
app.post('/api/register', async (req, res) => {
    const { username, email, password, name, gender, background } = req.body;

    if (!username || !email || !password || !name || !background) {
        return res.status(400).json({ error: 'All fields are required' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const createdAt = new Date().toISOString();

    db.serialize(() => {
        const stmt = db.prepare(`INSERT INTO users (username, email, password, created_at) VALUES (?, ?, ?, ?)`);
        stmt.run(username, email, hashedPassword, createdAt, function (err) {
            if (err) {
                return res.status(400).json({ error: 'User already exists' });
            }
            const userId = this.lastID; // 'this' refers to the statement context here

            // Initial Stats Logic
            let money, health, education, happiness;
            switch (background) {
                case 'Rich': money = 10000; health = 80; education = 70; happiness = 75; break;
                case 'Middle': money = 5000; health = 75; education = 60; happiness = 70; break;
                case 'Lower Middle': money = 3000; health = 70; education = 50; happiness = 65; break;
                case 'Poor': money = 1000; health = 65; education = 40; happiness = 60; break;
                case 'Very Poor': money = 500; health = 60; education = 30; happiness = 50; break;
                default: money = 5000; health = 75; education = 60; happiness = 70;
            }

            const hunger = 50;
            const relationship_score = 50;
            const initialAge = 5;
            const job = 'Unemployed';
            const profession_level = 0;

            db.run(`INSERT INTO characters (user_id, name, background, age, money, health, education, happiness, hunger, relationship_score, job, profession_level) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                [userId, name, background, initialAge, money, health, education, happiness, hunger, relationship_score, job, profession_level],
                (err) => {
                    if (err) return res.status(500).json({ error: err.message });
                    res.status(201).json({ message: 'User created successfully' });
                }
            );
        });
        stmt.finalize();
    });
});

// Login
app.post('/api/login', (req, res) => {
    const { identifier, password } = req.body;

    // Try to find by email OR username
    db.get(`SELECT * FROM users WHERE email = ? OR username = ?`, [identifier, identifier], async (err, user) => {
        if (err) return res.status(500).json({ error: err.message });
        if (!user) return res.status(400).json({ error: 'User not found' });

        const validPassword = await bcrypt.compare(password, user.password);
        if (!validPassword) return res.status(400).json({ error: 'Invalid password' });

        const isAdmin = user.username === 'admin';
        const token = jwt.sign({ id: user.id, username: user.username, isAdmin }, JWT_SECRET, { expiresIn: '24h' });
        res.json({ token, isAdmin });
    });
});

// Profile (Get User & Character Data + Dynamic Age Calculation)
app.get('/api/profile', authenticateToken, (req, res) => {
    db.get(`SELECT * FROM users WHERE id = ?`, [req.user.id], (err, user) => {
        if (err || !user) return res.status(404).json({ error: 'User not found' });

        db.get(`SELECT * FROM characters WHERE user_id = ?`, [req.user.id], (err, character) => {
            if (err || !character) return res.status(404).json({ error: 'Character not found' });

            // Calculate Dynamic Age
            const createdDate = new Date(user.created_at);
            const today = new Date();
            const diffTime = Math.abs(today - createdDate);
            const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));

            // 1 real day = 1 game day. 100 game days = +1 year.
            // Base age is 5.
            const calculatedAge = 5 + Math.floor(diffDays / 100);

            // Update age in DB if it's different (optional, but good for persistence)
            if (calculatedAge !== character.age) {
                db.run(`UPDATE characters SET age = ? WHERE id = ?`, [calculatedAge, character.id]);
                character.age = calculatedAge;
            }

            // Add calculated current game day (optional display)
            character.game_days_played = diffDays;

            res.json({ user: { username: user.username, email: user.email }, character });
        });
    });
});

// Action (Eat, Study, Work, etc.)
app.post('/api/action', authenticateToken, (req, res) => {
    const { actionType } = req.body;
    const userId = req.user.id;

    db.get(`SELECT * FROM characters WHERE user_id = ?`, [userId], (err, character) => {
        if (err || !character) return res.status(404).json({ error: 'Character not found' });

        // Logic for actions
        let { money, health, education, happiness, hunger, relationship_score } = character;

        // Ensure values are integers
        money = money || 0; health = health || 0; education = education || 0;
        happiness = happiness || 0; hunger = hunger || 0; relationship_score = relationship_score || 0;

        let message = '';

        switch (actionType) {
            case 'EAT':
                if (money < 10) return res.status(400).json({ error: 'Not enough money' });
                money -= 10;
                health = Math.min(100, health + 5);
                hunger = Math.max(0, hunger - 20); // Decreases hunger
                message = 'You ate a meal.';
                break;
            case 'STUDY':
                education += 2;
                happiness = Math.max(0, happiness - 5);
                message = 'You studied hard.';
                break;
            case 'WORK':
                money += 50; // Simple flat rate for now
                health = Math.max(0, health - 5);
                happiness = Math.max(0, happiness - 5);
                message = 'You went to work.';
                break;
            case 'SOCIALIZE':
                if (money < 20) return res.status(400).json({ error: 'Not enough money' });
                money -= 20;
                relationship_score += 5;
                happiness = Math.min(100, happiness + 10);
                message = 'You socialized with friends.';
                break;
            case 'REST':
                health = Math.min(100, health + 10);
                happiness = Math.min(100, happiness + 5);
                message = 'You rested well.';
                break;
            default:
                return res.status(400).json({ error: 'Invalid action' });
        }

        db.run(`UPDATE characters SET money = ?, health = ?, education = ?, happiness = ?, hunger = ?, relationship_score = ? WHERE id = ?`,
            [money, health, education, happiness, hunger, relationship_score, character.id],
            (err) => {
                if (err) return res.status(500).json({ error: err.message });
                res.json({
                    message,
                    stats: { money, health, education, happiness, hunger, relationship_score }
                });
            }
        );
    });
});

// --- ADMIN ENDPOINTS ---

// List Users
app.get('/api/admin/users', authenticateAdmin, (req, res) => {
    db.all(`SELECT u.id, u.username, u.email, c.id as char_id, c.name as char_name, c.money FROM users u LEFT JOIN characters c ON u.id = c.user_id`, [], (err, rows) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(rows);
    });
});

// Delete User
app.delete('/api/admin/users/:id', authenticateAdmin, (req, res) => {
    const id = req.params.id;
    // Prevent deleting self (admin)
    if (id == req.user.id) {
        return res.status(400).json({ error: "Cannot delete yourself" });
    }

    db.serialize(() => {
        db.run(`DELETE FROM characters WHERE user_id = ?`, [id]);
        db.run(`DELETE FROM users WHERE id = ?`, [id], (err) => {
            if (err) return res.status(500).json({ error: err.message });
            res.json({ message: 'User deleted' });
        });
    });
});


// Seed Admin User
const seedAdmin = async () => {
    const username = 'admin';
    const password = 'admin@123'; // New requested password
    const email = 'admin@local'; // Placeholder email since it's unique/required by schema

    db.serialize(async () => {
        // 1. Delete all non-admin users
        db.run(`DELETE FROM characters WHERE user_id IN (SELECT id FROM users WHERE username != ?)`, [username]);
        db.run(`DELETE FROM users WHERE username != ?`, [username]);

        // 2. Check/Create/Update Admin
        db.get(`SELECT * FROM users WHERE username = ?`, [username], async (err, user) => {
            const hashedPassword = await bcrypt.hash(password, 10);

            if (!user) {
                const createdAt = new Date().toISOString();
                db.run(`INSERT INTO users (username, email, password, created_at) VALUES (?, ?, ?, ?)`,
                    [username, email, hashedPassword, createdAt], function (err) {
                        if (err) console.error("Error creating admin:", err);
                        else {
                            const userId = this.lastID;
                            db.run(`INSERT INTO characters (user_id, name, background, age, money, health, education, happiness, hunger, relationship_score, job, profession_level) 
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                                [userId, 'Admin', 'Rich', 99, 999999, 100, 100, 100, 0, 100, 'GodMode', 100]);
                            console.log("Admin user created: admin / admin@123");
                        }
                    }
                );
            } else {
                // Update password if exists
                db.run(`UPDATE users SET password = ? WHERE id = ?`, [hashedPassword, user.id]);
                console.log("Admin password updated to: admin@123");
            }
        });
    });
};

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
    seedAdmin();
});

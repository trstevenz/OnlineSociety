import React, { useState, useEffect, useRef } from 'react';
import api from '../services/api';

const ChatBox = ({ userRole }) => {
    const [messages, setMessages] = useState([]);
    const [input, setInput] = useState('');
    const bottomRef = useRef(null);
    const chatContainerRef = useRef(null);

    const fetchMessages = async () => {
        try {
            const res = await api.get('/chat');
            setMessages(res.data);
        } catch (err) {
            console.error("Chat error:", err);
        }
    };

    useEffect(() => {
        fetchMessages();
        const interval = setInterval(fetchMessages, 3000); // Poll every 3s
        return () => clearInterval(interval);
    }, []);

    // Initial scroll to bottom
    useEffect(() => {
        if (bottomRef.current) {
            bottomRef.current.scrollIntoView({ behavior: 'auto' });
        }
    }, []); // Only on mount

    // Smart scroll on new messages
    useEffect(() => {
        // If we are already near the bottom (within 100px), scroll to the new message
        const container = chatContainerRef.current;
        if (container) {
            const isNearBottom = container.scrollHeight - container.scrollTop - container.clientHeight < 150;
            if (isNearBottom) {
                bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
            }
        }
    }, [messages]);

    const handleSend = async (e) => {
        e.preventDefault();
        if (!input.trim()) return;
        try {
            await api.post('/chat', { message: input });
            setInput('');
            fetchMessages();
        } catch (err) {
            alert("Failed to send");
        }
    };

    return (
        <div className="glass-panel" style={{ height: '400px', display: 'flex', flexDirection: 'column' }}>
            <h3 style={{ borderBottom: '1px solid rgba(255,255,255,0.1)', paddingBottom: '0.5rem' }}>Global Chat</h3>
            <div ref={chatContainerRef} style={{ flex: 1, overflowY: 'auto', padding: '1rem', display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                {messages.map((msg) => (
                    <div key={msg.id} style={{
                        alignSelf: 'flex-start',
                        background: msg.role === 'admin' ? 'rgba(255, 215, 0, 0.2)' : 'rgba(255,255,255,0.05)',
                        padding: '0.5rem',
                        borderRadius: '0.5rem',
                        maxWidth: '80%'
                    }}>
                        <strong style={{ color: msg.role === 'admin' ? '#ffd700' : '#fff' }}>{msg.username}</strong>: {msg.message}
                        <div style={{ fontSize: '0.7rem', opacity: 0.5 }}>{new Date(msg.created_at).toLocaleTimeString()}</div>
                    </div>
                ))}
                <div ref={bottomRef} />
            </div>
            <form onSubmit={handleSend} style={{ display: 'flex', gap: '0.5rem', marginTop: 'auto' }}>
                <input
                    type="text"
                    value={input}
                    onChange={e => setInput(e.target.value)}
                    placeholder="Say something..."
                    style={{ flex: 1 }}
                />
                <button type="submit">Send</button>
            </form>
        </div>
    );
};

export default ChatBox;

const { spawn, execSync } = require('child_process');
const http = require('http');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const dbPath = path.resolve(__dirname, 'lifesociety.db');

function listUsers(label) {
    return new Promise((resolve) => {
        console.log(`\n--- ${label} ---`);
        const db = new sqlite3.Database(dbPath);
        db.all("SELECT id, username FROM users", (err, rows) => {
            if (err) console.log("DB Error:", err.message);
            else console.table(rows);
            db.close(resolve);
        });
    });
}

function startServer() {
    console.log("Starting Server...");
    const server = spawn('node', ['server.js'], { cwd: __dirname });
    server.stdout.on('data', d => process.stdout.write(`[SRV] ${d}`));
    return server;
}

function registerUser(username) {
    return new Promise((resolve, reject) => {
        const data = JSON.stringify({
            username, name: 'Test', email: `${username}@test.com`,
            password: 'pass', gender: 'Male', background: 'Middle'
        });
        const req = http.request({
            port: 5000, path: '/api/register', method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Content-Length': data.length }
        }, res => {
            res.on('data', () => { });
            res.on('end', () => resolve(res.statusCode));
        });
        req.on('error', reject);
        req.write(data);
        req.end();
    });
}

async function run() {
    // 1. Initial State
    await listUsers("BEFORE");

    // 2. Start Server
    const server = startServer();
    await new Promise(r => setTimeout(r, 3000));

    // 3. Register
    const newUser = `user_${Date.now()}`;
    console.log(`Registering ${newUser}...`);
    try {
        const code = await registerUser(newUser);
        console.log("Reg Code:", code);
    } catch (e) {
        console.log("Reg Failed:", e.message);
    }

    // 4. Kill Server
    console.log("Killing Server...");
    server.kill();
    try { execSync('taskkill /IM node.exe /F'); } catch (e) { }
    await new Promise(r => setTimeout(r, 2000));

    // 5. Final State
    await listUsers("AFTER");
}

run();

import React from 'react';

const ActionGrid = ({ onNavigate, activeTab }) => {
    const actions = [
        { id: 'profile', label: 'Profile', icon: '👤', color: '#3498db' },
        { id: 'work', label: 'Work', icon: '💼', color: '#e67e22' },
        { id: 'education', label: 'Education', icon: '🎓', color: '#9b59b6' },
        { id: 'store', label: 'Store', icon: '🛒', color: '#2ecc71' },
        { id: 'entertainment', label: 'Fun', icon: '🎭', color: '#e74c3c' },
        { id: 'community', label: 'Community', icon: '💬', color: '#f1c40f' },
    ];

    return (
        <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(3, 1fr)',
            gap: '0.8rem',
            padding: '1rem',
            background: 'rgba(0,0,0,0.2)',
            borderRadius: '12px'
        }}>
            {actions.map(action => (
                <button
                    key={action.id}
                    onClick={() => onNavigate(action.id)}
                    style={{
                        background: activeTab === action.id ? `rgba(255,255,255,0.1)` : 'rgba(255,255,255,0.05)',
                        border: `1px solid ${activeTab === action.id ? action.color : 'rgba(255,255,255,0.1)'}`,
                        borderRadius: '8px',
                        padding: '1rem 0.5rem',
                        display: 'flex',
                        flexDirection: 'column',
                        alignItems: 'center',
                        gap: '0.5rem',
                        cursor: 'pointer',
                        transition: 'all 0.2s',
                        color: activeTab === action.id ? 'white' : '#bdc3c7'
                    }}
                    onMouseEnter={(e) => {
                        e.currentTarget.style.transform = 'translateY(-2px)';
                        e.currentTarget.style.borderColor = action.color;
                    }}
                    onMouseLeave={(e) => {
                        e.currentTarget.style.transform = 'translateY(0)';
                        e.currentTarget.style.borderColor = activeTab === action.id ? action.color : 'rgba(255,255,255,0.1)';
                    }}
                >
                    <span style={{ fontSize: '1.5rem' }}>{action.icon}</span>
                    <span style={{ fontSize: '0.8rem', fontWeight: 'bold' }}>{action.label}</span>
                </button>
            ))}
        </div>
    );
};

export default ActionGrid;

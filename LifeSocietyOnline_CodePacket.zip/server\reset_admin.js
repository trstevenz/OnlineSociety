const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const bcrypt = require('bcrypt');

const dbPath = path.resolve(__dirname, 'lifesociety.db');
const db = new sqlite3.Database(dbPath);

const resetAdmin = async () => {
    const password = 'admin@123';
    const hashedPassword = await bcrypt.hash(password, 10);
    const createdAt = new Date().toISOString();

    db.serialize(() => {
        // Delete existing admin
        db.run("DELETE FROM users WHERE username = 'admin'");

        // Create fresh admin
        db.run(`INSERT INTO users (username, email, password, created_at, role, is_banned) VALUES ('admin', 'admin@local', ?, ?, 'admin', 0)`,
            [hashedPassword, createdAt],
            (err) => {
                if (err) console.error("Error:", err);
                else console.log("Admin RESET successfully. Login with admin / admin@123");
            });
    });
};

resetAdmin();
